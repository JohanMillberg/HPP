echo Hej hej
echo Jag
echo heter
echo Johan